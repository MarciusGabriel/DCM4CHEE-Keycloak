import{jsx as s}from"react/jsx-runtime";import{F as e}from"./FileUploadForm-BSqaRKUe.js";import{L as i}from"./CodeEditor--AHMF_Ho.js";const m=({onChange:o,...n})=>{const a=r=>{try{o(JSON.parse(r))}catch{o({}),console.warn("Invalid json, ignoring value using {}")}};return s(e,{...n,language:i.json,extension:".json",onChange:a})};export{m as J};
//# sourceMappingURL=JsonFileUpload-Dej5GsDK.js.map
