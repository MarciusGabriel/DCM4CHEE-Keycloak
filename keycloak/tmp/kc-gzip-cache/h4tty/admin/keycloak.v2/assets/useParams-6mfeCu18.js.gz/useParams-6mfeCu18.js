import{c as s}from"./main-C047jAp3.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-6mfeCu18.js.map
