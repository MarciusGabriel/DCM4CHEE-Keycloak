import{e1 as n}from"./main-C047jAp3.js";const c={dateStyle:"long",timeStyle:"short"};function l(){const{whoAmI:t}=n(),o=t.getLocale();return function(e,a){return e.toLocaleString(o,a)}}export{c as F,l as u};
//# sourceMappingURL=useFormatDate-Bn-bRoLD.js.map
